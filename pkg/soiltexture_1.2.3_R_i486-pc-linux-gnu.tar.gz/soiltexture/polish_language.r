lang.par2 <- data.frame( 
    "lang"  = "pl", 
    "CLAY"  = "\"Ił\"", 
    "SILT"  = "\"Pył\"", 
    "SAND"  = "\"Piasek\"", 
    "TT"    = "\"Trójkąt Fereta\"", 
    stringsAsFactors    = FALSE  
)   #

